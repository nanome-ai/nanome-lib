from {{folder}} import {{class}}

if __name__ == '__main__':
    {{class}}.main()
