docker build -f Dockerfile -t {{command}}:latest ..
