# Nanome - {{name}}

Ensure you have the latest `nanome` lib installed with:

```sh
$ pip3 install nanome --upgrade
```

Run the plugin:

```sh
$ python run.py -a <plugin_server_address> [optional args]
```

### License

MIT
